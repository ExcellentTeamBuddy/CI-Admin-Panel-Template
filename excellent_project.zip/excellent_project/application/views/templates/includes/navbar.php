		<nav class="navbar">
	        <div class="btn-group">	          
				<button class="btn-group__item" data-url="<?php echo base_url(); ?>admin/dashboard">Dashboard</button>
				<button class="btn-group__item" data-url="<?php echo base_url(); ?>admin/order">Orders</button>
				<button class="btn-group__item" data-url="<?php echo base_url(); ?>admin/product">Products</button>
				<button class="btn-group__item" data-url="<?php echo base_url(); ?>admin/user">Users</button>
				<button class="btn-group__item" data-url="<?php echo base_url(); ?>admin/login">Logout</button>	            
	        </div>
	    </nav>