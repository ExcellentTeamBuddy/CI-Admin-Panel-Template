<?php 
  $this->load->view('templates/includes/header'); 
?>
    <div>
      <?php 
        $this->load->view('templates/includes/navbar'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card ">           

            <div class="card-body">

              <div class="login-box" align="center">                
                <h1>Welcome To Admin Panel</h1>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->
    </div>
<?php 
  $this->load->view('templates/includes/footer'); 
?>