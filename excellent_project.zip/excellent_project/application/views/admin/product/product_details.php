<?php 
  $this->load->view('templates/includes/header'); 
?>
    <div>
      <?php 
        $this->load->view('templates/includes/navbar'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card">

            <div class="card-header my-card-header">
              <div class="row">
                <div class="col-6">
                  <h4>Product Details</h4>
                </div>
              </div>              
            </div>           

            <div class="card-body">

              <div class="login-box">                
                <div class="row">
                  <div class="col-sm-4">
                    <div class="my-product-image-thumb my-product-detail-image-div-width dt-product-details-width">
                      <img src="<?php echo base_url(); ?>assets/images/Gulab Supreme Refined Soyabean 15 Ltr - Jar.png" alt="">
                    </div>
                  </div>
                  <div class="col-sm-8">
                    <h4>Product Name: Gulab Supreme Refined Soyabean : 15 Liters</h4><br>
                    <h5>Price: 2350</h5>
                    <h5>Quantity: 10</h5><br>
                    <h5>Description:</h5> 
                    <p class="text-justify">
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->      

    </div>    

<?php 
  $this->load->view('templates/includes/footer'); 
?>