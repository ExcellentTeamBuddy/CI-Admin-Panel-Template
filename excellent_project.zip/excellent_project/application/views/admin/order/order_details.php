<?php 
  $this->load->view('templates/includes/header'); 
?>
    <div>
      <?php 
        $this->load->view('templates/includes/navbar'); 
      ?>
      <!-- Main Section -->
      <section class="main-card--cointainer my-section-grid">        
        <div class="card-container my-card-container">
          <div class="card">

            <div class="card-header my-card-header">
              <div class="row">
                <div class="col-6">
                  <h4>Order Details</h4>
                </div>                
              </div>              
            </div>           

            <div class="card-body">

              <div class="login-box">

                <!-- title row -->
                <div class="row">
                  <div class="col-12">
                    <h5>Delivery Details</h5>
                  </div>                    
                </div>
                <hr>                 

                <div class="row">
                  <div class="col-sm-6">
                    <address>                      
                      <b>John Smith</b><br>
                      C-305, ABC Apartment, Nr. ABC Tower, Landscal, USA.<br>
                      Phone: 1234567890                      
                    </address>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">                      
                    <b>Order Date:</b> 12/06/2002<br>
                    <b>Order Number:</b> OD1234567890<br>
                    <b>Order Status:</b> Pending
                  </div>
                  <!-- /.col -->                  
                </div>

                <hr>
                <!-- title row -->
                <div class="row">
                  <div class="col-12">
                    <h5>Bill Details</h5>
                  </div>                    
                </div>
                <hr>

                <table id="example1" class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Quantity</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div class="my-product-image-thumb dt-product-width">
                          <img src="<?php echo base_url(); ?>assets/images/Gulab Supreme Refined Soyabean 15 Ltr - Jar.png" alt="">
                        </div>
                      </td>
                      <td>Gulab Supreme Refined Soyabean : 15 Liters</td>
                      <td>2350</td>
                      <td>1</td>                    
                      <td>2350</td>
                    </tr>
                    <tr>
                      <td colspan="4" class="text-right">Grand Total: </td>
                      <td>2350</td>
                    </tr>                    
                  </tbody>
                </table>
              </div>

            </div>
          </div>
        </div>            
      </section>      
      <!-- Main Section -->      

    </div>    

<?php 
  $this->load->view('templates/includes/footer'); 
?>