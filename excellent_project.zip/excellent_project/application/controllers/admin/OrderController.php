<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OrderController extends CI_Controller {
	
	public function index()
	{
		$this->load->view('admin/order/index');
	}

	public function details()
	{
		$this->load->view('admin/order/order_details');
	}
}