<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductController extends CI_Controller {
	
	public function index()
	{
		$this->load->view('admin/product/index');
	}

	public function details()
	{
		$this->load->view('admin/product/product_details');
	}
}